import React, { Component } from 'react';
import '../styles/styles.css'; 

class Login extends Component {
    
    render() {
        return (
          <>
            <h1 className="h3 mb-5 font-weight-normal text-center ">Equipo de S.A.P.Felix</h1>
  <div className="quienes">    
    <p className="integrantes">Jose Alejandro López Rojas</p>
    <p className="integrantes">Juana Velazquez Tobón</p>
    <p className="integrantes">Jose Alejandro Gonzalez Villa</p>
    <p className="integrantes">Kevin Alexander Guzman Botero</p>
  </div>
</>

          ); 
        }
    }


 
export default Login;


